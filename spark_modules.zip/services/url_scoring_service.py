import hashlib
import re
from dataclasses import dataclass
from typing import Dict, Optional, Tuple
from collections import Counter
from datetime import datetime, timezone
import math

@dataclass
class URLAnalysisResult:
    url: str
    timestamp: str
    domain: str
    classification_score: float  # -1 (spam) to 1 (legitimate)
    confidence: float  # 0 to 1, how confident we are in the classification
    reasons: Dict
    domain_frequency: int
    domain_frequency_pct: float
    is_spam: bool  # True if score <= -0.3
    received_at: str

class URLClassifier:
    def __init__(self):
        self.compiled_patterns = self._compile_patterns()
        self._init_domain_sets()
        self._init_keyword_lookups()

    def _compile_patterns(self):
        return {
            'quality_patterns': re.compile(r'/(?:article|post|blog|news|research|documentation|guide|tutorial|paper|wiki)/'),
            'year_pattern': re.compile(r'\b(20[0-2][0-9])\b'),
            'age_restriction': re.compile(r'\b(?:18\+|21\+|adults?[\-_]?only|nsfw)\b'),
            'adult_site_pattern': re.compile(r'(?:tube|cam|live|chat)[\d]*\.(?:com|org|net)'),
            'suspicious_url_pattern': re.compile(r'(?:\.php\?.*=.*&.*=.*&.*=|[?&]id=\d{8,}|[?&]ref=\w{20,}|[?&]utm_[^&]{30,}|[?&]token=\w{30,})'),
            'long_numbers': re.compile(r'[0-9]{12,}'),
            'low_value_extensions': re.compile(r'\.(?:jpg|jpeg|png|gif|bmp|webp|svg|mp3|mp4|avi|mov|wmv|flv|zip|rar|7z|tar|gz|exe|msi|dmg|deb|rpm)$', re.IGNORECASE),
            'legitimate_paths': re.compile(r'/(?:about|contact|help|support|privacy|terms|faq|docs|api)/'),
            'spam_patterns': re.compile(r'(?:click-here|act-now|limited-time|special-offer|free-money|get-rich-quick)')
        }

    def _init_domain_sets(self):
        # Highly trusted domains (strong positive signal)
        self.trusted_domains = frozenset({
            'wikipedia.org', 'github.com', 'stackoverflow.com', 'medium.com',
            'reddit.com', 'youtube.com', 'vimeo.com', 'archive.org', 'arxiv.org',
            'nature.com', 'science.org', 'ieee.org', 'acm.org', 'springer.com',
            'cambridge.org', 'mit.edu', 'stanford.edu', 'harvard.edu', 'ox.ac.uk',
            'bbc.com', 'cnn.com', 'reuters.com', 'ap.org', 'npr.org', 'pbs.org',
            'theguardian.com', 'nytimes.com', 'washingtonpost.com', 'wsj.com',
            'bloomberg.com', 'economist.com', 'google.com', 'microsoft.com',
            'apple.com', 'amazon.com', 'facebook.com', 'twitter.com', 'linkedin.com'
        })

        # Quality domains (moderate positive signal)
        self.quality_domains = frozenset({
            'techcrunch.com', 'wired.com', 'arstechnica.com', 'hacker-news.com',
            'dev.to', 'codepen.io', 'jsfiddle.net', 'gitlab.com', 'bitbucket.org',
            'slack.com', 'discord.com', 'zoom.us', 'dropbox.com', 'netflix.com',
            'spotify.com', 'twitch.tv', 'instagram.com', 'pinterest.com'
        })

        # Adult content domains (negative signal)
        self.adult_domains = frozenset({
            'xnxx.com', 'pornhub.com', 'xvideos.com', 'redtube.com', 'youporn.com',
            'tube8.com', 'spankbang.com', 'xhamster.com', 'brazzers.com', 'realitykings.com',
            'sex.com', 'porn.com', 'xxx.com', 'adult.com', 'cam4.com', 'chaturbate.com',
            'onlyfans.com', 'pornstar.com', 'nuvid.com', 'motherless.com', 'slutload.com'
        })

        # Known spam/malicious domains (strong negative signal)
        self.spam_domains = frozenset({
            'bit.ly', 'tinyurl.com', 'goo.gl', 't.co'  # URL shorteners can be suspicious
            # Add known spam domains here
        })

        # Suspicious TLDs (negative signal)
        self.suspicious_tlds = frozenset({
            '.tk', '.ml', '.ga', '.cf', '.buzz', '.click', '.download', '.loan',
            '.win', '.bid', '.trade', '.date', '.racing', '.review', '.cricket',
            '.xxx', '.top', '.party', '.live', '.work', '.stream', '.faith',
            '.accountant', '.science', '.men', '.gdn', '.kim'
        })

        # Legitimate TLDs (positive signal)
        self.legitimate_tlds = frozenset({
            '.edu', '.gov', '.org', '.ac.uk', '.edu.au', '.ac.jp'
        })

    def _init_keyword_lookups(self):
        adult_keywords = [
            'porn', 'sex', 'xxx', 'adult', 'nude', 'naked', 'boobs', 'ass', 'pussy',
            'cock', 'dick', 'fuck', 'milf', 'teen', 'amateur', 'webcam', 'cam',
            'escort', 'hookup', 'dating', 'singles', 'erotic', 'sexy', 'hot',
            'fetish', 'bdsm', 'orgasm', 'masturbat', 'cumshot', 'blowjob'
        ]

        spam_keywords = [
            'casino', 'poker', 'betting', 'viagra', 'cialis', 'pharmacy', 'pills',
            'weight-loss', 'make-money', 'work-from-home', 'get-rich', 'free-money',
            'click-here', 'limited-time', 'act-now', 'special-offer', 'lottery',
            'winner', 'congratulations', 'urgent', 'claim', 'prize', 'bonus',
            'miracle', 'guaranteed', 'instant', 'secret', 'exclusive'
        ]

        quality_keywords = [
            'tutorial', 'guide', 'documentation', 'manual', 'howto', 'learn',
            'education', 'course', 'training', 'research', 'analysis', 'study',
            'article', 'blog', 'news', 'review', 'comparison', 'reference'
        ]

        self.adult_keywords_regex = re.compile('|'.join(re.escape(kw) for kw in adult_keywords), re.IGNORECASE)
        self.spam_keywords_regex = re.compile('|'.join(re.escape(kw) for kw in spam_keywords), re.IGNORECASE)
        self.quality_keywords_regex = re.compile('|'.join(re.escape(kw) for kw in quality_keywords), re.IGNORECASE)

    def extract_domain(self, url: str) -> Optional[str]:
        try:
            if '://' in url:
                domain = url.split('://', 1)[1]
            else:
                domain = url
            domain = domain.split('/', 1)[0].split('?', 1)[0].lower()
            return domain[4:] if domain.startswith('www.') else domain
        except:
            return None

    def get_url_fingerprint(self, url: str) -> str:
        return hashlib.md5(url.encode()).hexdigest()[:16]

    def get_tld(self, domain: str) -> Optional[str]:
        if not domain:
            return None
        last_dot = domain.rfind('.')
        return domain[last_dot:] if last_dot >= 0 else None

    def calculate_classification_score(self, url: str, timestamp: str, domain: str = None) -> Tuple[float, float, Dict]:
        """
        Calculate classification score from -1 (spam) to 1 (legitimate)
        Returns: (score, confidence, reasons)
        """
        if not domain:
            domain = self.extract_domain(url)
        if not domain:
            return -0.5, 0.1, {"error": "invalid_url"}

        # Initialize scoring components
        domain_score = 0.0
        content_score = 0.0
        structure_score = 0.0
        
        all_reasons = {}
        url_lower = url.lower()
        
        # Domain-based scoring
        domain_reasons = []
        if domain in self.trusted_domains:
            domain_score += 0.8
            domain_reasons.append("trusted_domain")
        elif domain in self.quality_domains:
            domain_score += 0.4
            domain_reasons.append("quality_domain")
        elif domain in self.adult_domains:
            domain_score -= 0.6
            domain_reasons.append("adult_domain")
        elif domain in self.spam_domains:
            domain_score -= 0.8
            domain_reasons.append("spam_domain")
        
        # TLD analysis
        tld = self.get_tld(domain)
        if tld in self.legitimate_tlds:
            domain_score += 0.3
            domain_reasons.append(f"legitimate_tld({tld})")
        elif tld in self.suspicious_tlds:
            domain_score -= 0.4
            domain_reasons.append(f"suspicious_tld({tld})")
        
        if domain_reasons:
            all_reasons['domain'] = domain_reasons

        # Content-based scoring
        content_reasons = []
        
        # Quality indicators
        quality_matches = len(self.quality_keywords_regex.findall(url_lower))
        if quality_matches > 0:
            content_score += min(quality_matches * 0.15, 0.5)
            content_reasons.append(f"quality_keywords({quality_matches})")
        
        if self.compiled_patterns['quality_patterns'].search(url_lower):
            content_score += 0.2
            content_reasons.append("quality_path")
        
        if self.compiled_patterns['legitimate_paths'].search(url_lower):
            content_score += 0.1
            content_reasons.append("legitimate_path")
        
        if self.compiled_patterns['year_pattern'].search(url):
            content_score += 0.1
            content_reasons.append("dated_content")
        
        # Negative content indicators
        adult_matches = len(self.adult_keywords_regex.findall(url_lower))
        if adult_matches > 0:
            content_score -= min(adult_matches * 0.2, 0.6)
            content_reasons.append(f"adult_keywords({adult_matches})")
        
        spam_matches = len(self.spam_keywords_regex.findall(url_lower))
        if spam_matches > 0:
            content_score -= min(spam_matches * 0.25, 0.7)
            content_reasons.append(f"spam_keywords({spam_matches})")
        
        if self.compiled_patterns['age_restriction'].search(url_lower):
            content_score -= 0.3
            content_reasons.append("age_restriction")
        
        if self.compiled_patterns['spam_patterns'].search(url_lower):
            content_score -= 0.4
            content_reasons.append("spam_patterns")
        
        if content_reasons:
            all_reasons['content'] = content_reasons

        # Structure-based scoring
        structure_reasons = []
        
        # Positive structure indicators
        if url.startswith('https://'):
            structure_score += 0.1
            structure_reasons.append("https_secure")
        
        # Negative structure indicators
        if self.compiled_patterns['low_value_extensions'].search(url):
            structure_score -= 0.2
            structure_reasons.append("media_file")
        
        url_len = len(url)
        if url_len > 300:
            structure_score -= 0.3
            structure_reasons.append("extremely_long_url")
        elif url_len > 200:
            structure_score -= 0.15
            structure_reasons.append("long_url")
        
        if '?' in url:
            params = url.count('&') + 1
            if params > 20:
                structure_score -= 0.4
                structure_reasons.append(f"excessive_params({params})")
            elif params > 10:
                structure_score -= 0.2
                structure_reasons.append(f"many_params({params})")
        
        if self.compiled_patterns['long_numbers'].search(url):
            structure_score -= 0.2
            structure_reasons.append("long_numbers")
        
        if self.compiled_patterns['suspicious_url_pattern'].search(url):
            structure_score -= 0.3
            structure_reasons.append("suspicious_patterns")
        
        if url.count('-') > 8 or url.count('_') > 8:
            structure_score -= 0.15
            structure_reasons.append("excessive_separators")
        
        if structure_reasons:
            all_reasons['structure'] = structure_reasons

        # Combine scores with weights
        final_score = (
            domain_score * 0.5 +      # Domain is most important
            content_score * 0.3 +     # Content is second most important
            structure_score * 0.2     # Structure is least important
        )
        
        # Clamp to [-1, 1] range
        final_score = max(-1.0, min(1.0, final_score))
        
        # Calculate confidence based on how many signals we have
        total_signals = len(domain_reasons) + len(content_reasons) + len(structure_reasons)
        confidence = min(1.0, total_signals * 0.15 + 0.1)  # Base confidence of 0.1
        
        # Higher confidence for extreme scores
        if abs(final_score) > 0.7:
            confidence = min(1.0, confidence + 0.2)
        
        return final_score, confidence, all_reasons

def process_batch_worker_optimized(rows_list):
    classifier = URLClassifier()
    results = []

    # Convert to list if it's an iterator
    if hasattr(rows_list, '__iter__') and not isinstance(rows_list, (list, tuple)):
        rows_list = list(rows_list)

    # Count domain frequencies in this batch
    domain_counter = Counter()
    for row in rows_list:
        # Handle different row types
        if hasattr(row, 'url') and row.url:
            url = row.url
        elif isinstance(row, dict):
            url = row.get('url', '')
        elif isinstance(row, (list, tuple)) and len(row) > 1:
            url = row[1]  # URL is second column in TSV
        else:
            continue
            
        if url:
            domain = classifier.extract_domain(url)
            if domain:
                domain_counter[domain] += 1

    url_fingerprints = set()

    for row in rows_list:
        try:
            if hasattr(row, 'url'):
                url = row.url
                timestamp = getattr(row, 'timestamp', '')
            elif isinstance(row, dict):
                url = row.get('url', '')
                timestamp = row.get('timestamp', '')
            elif isinstance(row, (list, tuple)) and len(row) > 1:
                # TSV format: timestamp, url
                url = row[1]
                timestamp = row[0]
            else:
                print(f"Warning: Unknown row type encountered: {type(row)}. Skipping.")
                continue

            if not url:
                continue

            domain = classifier.extract_domain(url)
            if not domain:
                print(f"Warning: Could not extract domain for URL: {url}. Skipping.")
                continue

            current_domain_frequency = domain_counter[domain]
            domain_frequency_pct = (current_domain_frequency / len(rows_list)) if rows_list else 0.0
            
            fingerprint = classifier.get_url_fingerprint(url)
            if fingerprint in url_fingerprints:
                continue
            url_fingerprints.add(fingerprint)

            classification_score, confidence, reasons = classifier.calculate_classification_score(url, timestamp, domain)
            is_spam = classification_score <= -0.3  # Threshold for spam classification
            received_at_dt = datetime.now(timezone.utc)

            results.append(URLAnalysisResult(
                url=url,
                timestamp=timestamp,
                domain=domain,
                classification_score=classification_score,
                confidence=confidence,
                reasons=reasons,
                domain_frequency=current_domain_frequency,
                domain_frequency_pct=domain_frequency_pct,
                is_spam=is_spam,
                received_at=received_at_dt.isoformat()
            ))
        except Exception as e:
            print(f"Error processing URL {row.get('url', str(row)) if isinstance(row, dict) else str(row)}: {e}")
            import traceback
            traceback.print_exc()
            continue

    return results